//
//  HelloWorldViewController.h
//  HelloWorld
//
//  Created by Simon on 12/10/13.
//  Copyright (c) 2013 Appcoda. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HelloWorldViewController : UIViewController

-(IBAction)showMessage;

@end
